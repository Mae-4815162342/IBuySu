import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("d7ab59d9-b6c6-421b-bdb7-97d708514be9")
public class Catégorie {
    @mdl.prop
    @objid ("9bc78e57-1647-4406-8dde-b3e35db6edce")
    private String nom;

    @mdl.propgetter
    public String getNom() {
        // Automatically generated method. Please do not modify this code.
        return this.nom;
    }

    @mdl.propsetter
    public void setNom(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.nom = value;
    }

    @objid ("964b1d68-5e27-4cde-8064-b7f752780d69")
    public List<Catégorie> sous-categories = new ArrayList<Catégorie> ();

    @objid ("e11fc760-f324-43da-9cb8-cf7d26a80450")
    public List<Produit> produits = new ArrayList<Produit> ();

}
