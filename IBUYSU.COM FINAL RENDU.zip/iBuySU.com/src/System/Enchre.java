package System;

import java.util.ArrayList;
import java.util.List;

public class Enchère extends Produit {
    private int duree enchere;

    private int getDuree enchere() {
        // Automatically generated method. Please do not modify this code.
        return this.duree enchere;
    }

    private void setDuree enchere(final int value) {
        // Automatically generated method. Please do not modify this code.
        this.duree enchere = value;
    }

    public List<Offre> offres = new ArrayList<Offre> ();

    public Enchère() {
    }

    public void updatePrice() {
    }

    public static void updateEnchere() {
    }

}
