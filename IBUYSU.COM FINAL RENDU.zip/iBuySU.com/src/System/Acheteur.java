package System;

import java.util.ArrayList;
import java.util.List;

public class Acheteur extends Inscrit {
    public List<Offre> offres = new ArrayList<Offre> ();

    public static void participerEnchere() {
    }

    public Acheteur() {
    }

}
