package System;


public class Produit {
    private String description;

    private String getDescription() {
        // Automatically generated method. Please do not modify this code.
        return this.description;
    }

    private void setDescription(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.description = value;
    }

    private String photo;

    private String getPhoto() {
        // Automatically generated method. Please do not modify this code.
        return this.photo;
    }

    private void setPhoto(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.photo = value;
    }

    private int prix;

    private int getPrix() {
        // Automatically generated method. Please do not modify this code.
        return this.prix;
    }

    private void setPrix(final int value) {
        // Automatically generated method. Please do not modify this code.
        this.prix = value;
    }

    private boolean isSold;

    private boolean isIsSold() {
        // Automatically generated method. Please do not modify this code.
        return this.isSold;
    }

    private void setIsSold(final boolean value) {
        // Automatically generated method. Please do not modify this code.
        this.isSold = value;
    }

    private boolean isReceived;

    private Vendeur vendeur;

}
