package System;


public class Carte-Bancaire extends Données bancaires {
    private String date-expiration;

    private String getDate-expiration() {
        // Automatically generated method. Please do not modify this code.
        return this.date-expiration;
    }

    private void setDate-expiration(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.date-expiration = value;
    }

    private int cvc;

    private int getCvc() {
        // Automatically generated method. Please do not modify this code.
        return this.cvc;
    }

    private void setCvc(final int value) {
        // Automatically generated method. Please do not modify this code.
        this.cvc = value;
    }

    private int numero-carte;

    private int getNumero-carte() {
        // Automatically generated method. Please do not modify this code.
        return this.numero-carte;
    }

    private void setNumero-carte(final int value) {
        // Automatically generated method. Please do not modify this code.
        this.numero-carte = value;
    }

    public Carte-Bancaire() {
    }

}
