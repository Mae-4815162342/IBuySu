package System;

import java.util.ArrayList;
import java.util.List;

public class MotClef {
    private String nom;

    public String getNom() {
        // Automatically generated method. Please do not modify this code.
        return this.nom;
    }

    public void setNom(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.nom = value;
    }

    public List<Produit> produits = new ArrayList<Produit> ();

    public void setProduits(final List<Produit> value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.produits = value;
    }

    public List<Produit> getProduits() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.produits;
    }

    public void compare() {
    }

}
