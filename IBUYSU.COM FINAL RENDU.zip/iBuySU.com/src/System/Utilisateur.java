package System;


public abstract class Utilisateur {
    private static int id;

    public Utilisateur() {
    }

    public void getMenu() {
    }

    public void getMenuRecherche() {
    }

    public void getAffichageMinimal() {
    }

    public static int getId() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return id;
    }

}
