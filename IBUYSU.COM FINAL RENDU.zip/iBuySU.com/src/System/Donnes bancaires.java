package System;


public abstract class Données bancaires {
    private String banque;

    private String titulaire;

    public String getTitulaire() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.titulaire;
    }

    public void setTitulaire(final String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.titulaire = value;
    }

    public String getBanque() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.banque;
    }

    public void setBanque(final String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.banque = value;
    }

}
