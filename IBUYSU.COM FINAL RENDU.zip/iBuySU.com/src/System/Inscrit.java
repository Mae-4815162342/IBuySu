package System;


public abstract class Inscrit extends Utilisateur {
    protected String nom;

    protected String prenom;

    protected int numero-tel;

    protected String mail;

    protected String pseudo;

    protected String motdepasse;

    private Adresse adresse;

    public static void updateEvaluation() {
    }

    public static void updateInscrit() {
    }

    public void verifMdp() {
    }

    public void getFormulaireConnexion() {
    }

    public void addContrat() {
    }

    public void getClosedContracts() {
    }

    public void creerEvaluation() {
    }

    public void getMenu()() {
    }

    public String getNom() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.nom;
    }

    public String getPrenom() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.prenom;
    }

    public int getNumero-tel() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.numero-tel;
    }

    public String getMail() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.mail;
    }

    public String getPseudo() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.pseudo;
    }

    public String getMotdepasse() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.motdepasse;
    }

    public Adresse getAdresse() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.adresse;
    }

    public static void getFormulaireInscription() {
    }

}
