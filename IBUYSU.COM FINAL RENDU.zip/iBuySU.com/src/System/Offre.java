package System;


public class Offre {
    public int somme;

    public Offre() {
    }

}
