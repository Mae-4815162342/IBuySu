package System;

import java.util.ArrayList;
import java.util.List;

public class iBuySU.com {
    private List<Catégorie> categories = new ArrayList<Catégorie> ();

    private List<Inscrit> users = new ArrayList<Inscrit> ();

    private List<MotClef> motClef = new ArrayList<MotClef> ();

    public Produit ListeProduit;

    private Inscrit user;

    private static final iBuySU.com system;

    public MotClef getMotClef() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.motClef;
    }

    public void setMotClef(final MotClef value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.motClef = value;
    }

    public List<Inscrit> getUsers() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.users;
    }

    public void setUsers(final List<Inscrit> value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.users = value;
    }

    public Inscrit getUser() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.user;
    }

    public void setUser(final Inscrit value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.user = value;
    }

    public List<Catégorie> getCategories() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.categories;
    }

    public void setCategories(final List<Catégorie> value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.categories = value;
    }

    private iBuySU.com() {
    }

    public static void getSystem() {
    }

    public void getMenu() {
    }

    public void connexion() {
    }

    public void deconnexion() {
    }

    public void rechercherparMotClef() {
    }

    public void getMenuCateg() {
    }

    public void rechercherParCategorie() {
    }

    public void displayListOfProduct() {
    }

    public void rechercher() {
    }

    public void buyorBack() {
    }

    public void acheterObjetEnchere() {
    }

    public void acheterUnObjet() {
    }

    public void evaluerUnUtilisateur() {
    }

    public void inscriptionAcheteur() {
    }

    public void inscriptionVendeur() {
    }

    public void getCategorie() {
    }

    public void displayVendeurAnnonces() {
    }

    public void addOrCreatMotClef() {
    }

    public void creerUnVente() {
    }

    public void gererMesVentes() {
    }

    public void accepterRefuserVente() {
    }

}
