import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("7a6e29ec-104a-414d-b697-8b8bbd2778f1")
public class Mot-clé {
    @mdl.prop
    @objid ("58bc2914-d84c-4d52-b99b-d0f0ac3213dd")
    private String nom;

    @mdl.propgetter
    public String getNom() {
        // Automatically generated method. Please do not modify this code.
        return this.nom;
    }

    @mdl.propsetter
    public void setNom(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.nom = value;
    }

    @objid ("2fc67279-e65e-4f2f-acf0-baba7532cce0")
    public List<Produit> produits = new ArrayList<Produit> ();

}
