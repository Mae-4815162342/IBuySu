import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("2aa71409-3069-433b-af05-3af72352a538")
public class IHM Visiteur extends IHM {
    @objid ("46957a74-18d6-4693-a6ea-e09946431869")
    private void creerCompteVendeur() {
    }

    @objid ("27a05f58-8611-4597-aa2c-4acbe3523b6b")
    private void creerCompteClient() {
    }

}
