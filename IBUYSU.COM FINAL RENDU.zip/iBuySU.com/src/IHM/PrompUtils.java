package IHM;


public class PrompUtils {
    private static final String E;

    private static final String C;

    private static final String B;

    private static final String RED;

    private static final String GRN;

    private static final String YEL;

    private static final String BLU;

    private static final String MAG;

    public static void b() {
    }

    public static void red() {
    }

    public static void grn() {
    }

    public static void yel() {
    }

    public static void blu() {
    }

    public static void mag() {
    }

    public static void printError() {
    }

    public static void printSuccess() {
    }

}
