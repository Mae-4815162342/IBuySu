package IHM;

import System.iBuySU.com;

public abstract class IHM {
    public iBuySU.com system;

    public static void getUserIn() {
    }

    private static void waitAnswerMenu() {
    }

    public static void getMenuUtilisateur() {
    }

    private static void waitAnswer() {
    }

    public static void remplirFormulaire() {
    }

    public static void deroulerMenu() {
    }

}
