import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("9e91d6f0-ca67-4aa5-b108-b87530cfa08d")
public class Vendeur extends Inscrit {
    @objid ("0cde56bb-4daa-4097-8033-853fcef7fb44")
    public Données bancaires données bancaires;

    @objid ("96ac1e88-912a-4dad-b256-94a4f4484f46")
    public Vendeur() {
    }

}
