import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("61e62744-6176-4658-ac38-b6a7a3c5208b")
public class Evaluation {
    @mdl.prop
    @objid ("a6c4dbdd-8e41-456a-a2bf-0f23f72fe3df")
    private int valeur;

    @mdl.propgetter
    public int getValeur() {
        // Automatically generated method. Please do not modify this code.
        return this.valeur;
    }

    @mdl.propsetter
    public void setValeur(final int value) {
        // Automatically generated method. Please do not modify this code.
        this.valeur = value;
    }

    @mdl.prop
    @objid ("336d8a7a-b6b9-4ee5-a2e3-86fc2769ebe9")
    private String avis;

    @mdl.propgetter
    public String getAvis() {
        // Automatically generated method. Please do not modify this code.
        return this.avis;
    }

    @mdl.propsetter
    public void setAvis(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.avis = value;
    }
    private Inscrit utilisateur;

    @mdl.propgetter
    public Inscrit getUtilisateur() {
        // Automatically generated method. Please do not modify this code.
        return this.utilisateur;
    }

    @mdl.propsetter
    public void setUtilisateur(final Inscrit utilisateur) {
        // Automatically generated method. Please do not modify this code.
        this.utilisateur = utilisateur;
    }

    @objid ("c8d57caa-fb79-4889-a343-9959b7fb11f7")
    public Evaluation() {
    }

    public static insert(Evaluation e) {
        // Se placer sur la table de Evaluations
        // Ajouter une nouvelle ligne avec les infos de e
        // Ajouter la clé étrangre de l'utilisateur
        // Retourne e 
    }

}
