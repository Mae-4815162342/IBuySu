import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("4de6cb80-9d96-4cb0-a77b-be58870fce2d")
public class Carte-Bancaire extends Données bancaires {
    @mdl.prop
    @objid ("08733ea7-d6cb-49fd-8288-d2c43fc469d8")
    private String date-expiration;

    @mdl.propgetter
    private String getDate-expiration() {
        // Automatically generated method. Please do not modify this code.
        return this.date-expiration;
    }

    @mdl.propsetter
    private void setDate-expiration(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.date-expiration = value;
    }

    @mdl.prop
    @objid ("1c050981-862e-486b-869b-e5f1bb73524f")
    private int cvc;

    @mdl.propgetter
    private int getCvc() {
        // Automatically generated method. Please do not modify this code.
        return this.cvc;
    }

    @mdl.propsetter
    private void setCvc(final int value) {
        // Automatically generated method. Please do not modify this code.
        this.cvc = value;
    }

    @mdl.prop
    @objid ("b9eaac75-b08f-45fa-a295-6d1cf40cf329")
    private int numero-carte;

    @mdl.propgetter
    private int getNumero-carte() {
        // Automatically generated method. Please do not modify this code.
        return this.numero-carte;
    }

    @mdl.propsetter
    private void setNumero-carte(final int value) {
        // Automatically generated method. Please do not modify this code.
        this.numero-carte = value;
    }

    @objid ("3ef4addb-6984-4802-9ef7-2153de68936d")
    public Carte-Bancaire() {
    }

}
