import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("b8252574-5441-46b1-bd5e-9f9b5a84fb54")
public class Vente directe extends Produit {
    @objid ("01bd1a45-cda5-44a8-b623-cdb528b1dd26")
    public Vente directe() {
    }

}
