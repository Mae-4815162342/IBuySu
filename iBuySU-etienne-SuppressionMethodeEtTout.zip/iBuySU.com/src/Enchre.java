import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("9f451a9e-983a-4a70-92bc-56225cac045f")
public class Enchère extends Produit {
    @mdl.prop
    @objid ("fdf78e3e-c517-4a1b-9d14-5ef668df7c1f")
    private int duree enchere;

    @mdl.propgetter
    private int getDuree enchere() {
        // Automatically generated method. Please do not modify this code.
        return this.duree enchere;
    }

    @mdl.propsetter
    private void setDuree enchere(final int value) {
        // Automatically generated method. Please do not modify this code.
        this.duree enchere = value;
    }

    @objid ("d1181a74-b20d-45d5-a2f5-abe47d60ba02")
    public List<Offre> offres = new ArrayList<Offre> ();

    @objid ("bc3b881a-c9e3-4352-842c-a903b07e5585")
    public Enchère() {
    }

    @objid ("e0334e5e-4bc8-4071-88e5-cc6f047f05b9")
    public void updatePrice() {
    }
}
