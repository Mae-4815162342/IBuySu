import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("a1d7ab92-b952-444d-ae0e-dc848909adef")
public abstract class Produit {
    @mdl.prop
    @objid ("dc427f07-0013-486d-9dce-e6251cf5de41")
    private String description;

    @mdl.propgetter
    private String getDescription() {
        // Automatically generated method. Please do not modify this code.
        return this.description;
    }

    @mdl.propsetter
    private void setDescription(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.description = value;
    }

    @mdl.prop
    @objid ("114c5dd4-d9f4-443e-85a1-3c53d1f7ca6e")
    private String photo;

    @mdl.propgetter
    private String getPhoto() {
        // Automatically generated method. Please do not modify this code.
        return this.photo;
    }

    @mdl.propsetter
    private void setPhoto(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.photo = value;
    }

    @mdl.prop
    @objid ("3bde6a68-6747-4cee-8d21-a6a49b3dc254")
    private int prix_de_depart;

    @mdl.propgetter
    private int getPrix_de_depart() {
        // Automatically generated method. Please do not modify this code.
        return this.prix_de_depart;
    }

    @mdl.propsetter
    private void setPrix_de_depart(final int value) {
        // Automatically generated method. Please do not modify this code.
        this.prix_de_depart = value;
    }

    @mdl.prop
    @objid ("86ce8bff-9cdd-45fc-9f32-3ce3b08e7924")
    private boolean estVendu;

    @mdl.propgetter
    private boolean isEstVendu() {
        // Automatically generated method. Please do not modify this code.
        return this.estVendu;
    }

    @mdl.propsetter
    private void setEstVendu(final boolean value) {
        // Automatically generated method. Please do not modify this code.
        this.estVendu = value;
    }

    @mdl.prop
    @objid ("96d18303-e714-4f03-938b-e3e2cacf6d0c")
    private boolean estRecu;

    @objid ("aab5278e-ff3c-42b5-a669-62850987ab4f")
    public Vendeur vendeur;

}
