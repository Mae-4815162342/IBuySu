package BDD;


public class API {
    public static String con;

    public static void connexion() {
    }

    public static void addAcheteur() {
    }

    public static void fetchUsers() {
    }

    public static void fetchCategories() {
    }

    public static void fetchSousCategories() {
    }

    public static void fetchProductByCategorie() {
    }

    public static void fetchProductByMotcle() {
    }

    public static void fetchMotClef() {
    }

    public static void addVendeur() {
    }

    public static void fetchNbProducts() {
    }

    public static void getNbInscrit() {
    }

}
