import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("d10f238c-0132-4e7c-ab2e-f3fae3f8fc43")
public abstract class Inscrit {
    @mdl.prop
    @objid ("629a1a95-440f-4341-93c9-a99056e96c4d")
    private String nom;

    @mdl.propgetter
    public String getNom() {
        // Automatically generated method. Please do not modify this code.
        return this.nom;
    }

    @mdl.propsetter
    public void setNom(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.nom = value;
    }

    @mdl.prop
    @objid ("9d0b8119-dc3b-44b3-ad52-34811dde2b59")
    private String prenom;

    @mdl.propgetter
    public String getPrenom() {
        // Automatically generated method. Please do not modify this code.
        return this.prenom;
    }

    @mdl.propsetter
    public void setPrenom(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.prenom = value;
    }

    @mdl.prop
    @objid ("4c33a3ec-c9ef-44f1-9612-a9caa63ea674")
    private int numero-tel;

    @mdl.propgetter
    public int getNumero-tel() {
        // Automatically generated method. Please do not modify this code.
        return this.numero-tel;
    }

    @mdl.propsetter
    public void setNumero-tel(final int value) {
        // Automatically generated method. Please do not modify this code.
        this.numero-tel = value;
    }

    @mdl.prop
    @objid ("46c00960-c4e6-4e7d-8d24-1bb460972f19")
    private String mail;

    @mdl.propgetter
    public String getMail() {
        // Automatically generated method. Please do not modify this code.
        return this.mail;
    }

    @mdl.propsetter
    public void setMail(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.mail = value;
    }

    @mdl.prop
    @objid ("0b7f4c6e-890a-4502-a8a4-4061235315bc")
    private String id;

    @mdl.propgetter
    public String getId() {
        // Automatically generated method. Please do not modify this code.
        return this.id;
    }

    @mdl.propsetter
    public void setId(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.id = value;
    }

    @mdl.prop
    @objid ("d08565ff-e563-48af-9a1f-876608acbdb9")
    private String motdepasse;

    @mdl.propgetter
    public String getMotdepasse() {
        // Automatically generated method. Please do not modify this code.
        return this.motdepasse;
    }

    @mdl.propsetter
    public void setMotdepasse(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.motdepasse = value;
    }

    @objid ("729076a4-4c78-4384-a017-c77077009e06")
    public List<Evaluation> evaluations = new ArrayList<Evaluation> ();

    @objid ("5b8b4858-e9f9-473e-b35f-b16a665bf06e")
    public Adresse adresse;

    @objid ("5ef69fd6-a12f-4255-a41e-910301b77642")
    public void updateRating() {
    }

}
