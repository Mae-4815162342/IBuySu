package IHM;


public class Main {
    private boolean exiting;

    public static void main() {
    }

    public static void exit() {
    }

    public static void traiterChoix() {
    }

}
