import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("2ea1a2e9-7049-4324-8bc2-cec0bbf7d0b3")
public class Acheteur extends Inscrit {
    @objid ("1d180628-f953-4eac-a358-69885ed3de8f")
    public List<Offre> offres = new ArrayList<Offre> ();

}
