package System;


public class RIB extends Données bancaires {
    private String IBAN;

    private String getIBAN() {
        // Automatically generated method. Please do not modify this code.
        return this.IBAN;
    }

    private void setIBAN(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.IBAN = value;
    }

    private String BIC;

    private String getBIC() {
        // Automatically generated method. Please do not modify this code.
        return this.BIC;
    }

    private void setBIC(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.BIC = value;
    }

    public RIB() {
    }

}
