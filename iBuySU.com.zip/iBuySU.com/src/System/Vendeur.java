package System;


public class Vendeur extends Inscrit {
    public Données bancaires données bancaires;

    public Vendeur() {
    }

    public void addProduit() {
    }

    public void removeProduit() {
    }

    public Données bancaires getDonnées bancaires() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.données bancaires;
    }

}
