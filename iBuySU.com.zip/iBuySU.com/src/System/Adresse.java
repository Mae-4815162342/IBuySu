package System;


public class Adresse {
    private String ville;

    private String getVille() {
        // Automatically generated method. Please do not modify this code.
        return this.ville;
    }

    private void setVille(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.ville = value;
    }

    private int code-postale;

    private int getCode-postale() {
        // Automatically generated method. Please do not modify this code.
        return this.code-postale;
    }

    private void setCode-postale(final int value) {
        // Automatically generated method. Please do not modify this code.
        this.code-postale = value;
    }

    private String pays ;

    private String getPays () {
        // Automatically generated method. Please do not modify this code.
        return this.pays ;
    }

    private void setPays (final String value) {
        // Automatically generated method. Please do not modify this code.
        this.pays  = value;
    }

    private int numero-rue;

    private int getNumero-rue() {
        // Automatically generated method. Please do not modify this code.
        return this.numero-rue;
    }

    private void setNumero-rue(final int value) {
        // Automatically generated method. Please do not modify this code.
        this.numero-rue = value;
    }

    private String nom-rue;

    private String getNom-rue() {
        // Automatically generated method. Please do not modify this code.
        return this.nom-rue;
    }

    private void setNom-rue(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.nom-rue = value;
    }

    public void verif() {
    }

    public void toString() {
    }

}
