package System;


public class Evaluation {
    private int note;

    public int getNote() {
        // Automatically generated method. Please do not modify this code.
        return this.note;
    }

    public void setNote(final int value) {
        // Automatically generated method. Please do not modify this code.
        this.note = value;
    }

    private String avis;

    public String getAvis() {
        // Automatically generated method. Please do not modify this code.
        return this.avis;
    }

    public void setAvis(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.avis = value;
    }

    public Inscrit auteur;

    public Inscrit destinataire;

    public Evaluation() {
    }

    public void toString() {
    }

}
