package System;


public class Contrat {
    private boolean int;

    private boolean isConcluded;

    private Vendeur vendeur;

    private Acheteur acheteur;

    private Produit produit;

    public boolean isIsConcluded() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.isConcluded;
    }

    public void concludeContrat() {
    }

    public Produit getProduit() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.produit;
    }

    public Vendeur getVendeur() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.vendeur;
    }

    public Acheteur getAcheteur() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.acheteur;
    }

    public void toString() {
    }

}
