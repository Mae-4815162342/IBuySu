import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("eddaefaa-b203-4fa3-86bf-1b2d1392f29a")
public abstract class IHM {
    @objid ("1fcc09f2-02a0-468b-9e9f-6ab4856fb699")
    private iBuySU.com service;

    @objid ("47ee6b4a-af4f-4b66-8907-ed46ddfff84b")
    private void afficherProduit() {
    }

    @objid ("bd14f410-d2a4-4f10-a3d0-1d4d7ef592b9")
    private void formulaireInscriptionVendeur() {
    }

    @objid ("5ea8dc82-b105-4e6f-8eea-68a00e105f14")
    private void formulaireInscriptionAcheteur() {
    }

    @objid ("992bf11b-e0c5-4e64-b5b7-171ea9c761dd")
    private void afficherListeProduit() {
    }

    @objid ("b0193b47-c74b-4f93-a2c4-58f69ed07d26")
    private void fomulaireConnexion() {
    }

    @objid ("ffc6248d-6858-4395-9b29-a0d6cde597d1")
    private void rechercher() {
    }

    @objid ("fb341c3f-145e-4607-9bc3-7384d1d06185")
    public static void menu() {
    }

    @objid ("d385a3d1-cb37-420c-aa7c-96f0f8750065")
    private void deconnecter() {
    }

    @objid ("77bfb4ff-74b5-44a5-95a1-4f85fec67434")
    private void evaluer() {
    }

}
