import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("1976f98c-e88b-4599-97f1-3737a03db20e")
public class iBuySU.com {
    @objid ("76a1369a-11e8-4903-9056-a2cfdf22d260")
    private String userToken;

    @objid ("abe285f6-b372-497a-80b1-acab03531b16")
    private iBuySU.com session;

    @objid ("6d00dabf-25b7-4b26-91fc-28f6202561d8")
    public Catégorie catégories;

    @objid ("f1f068aa-5c7b-4aa2-b821-cc93a5b236b9")
    public Evaluation ;

    @objid ("56a2d7ed-0108-43fa-af18-7a0aa1faca44")
    private Mot-clé listeMotsClés;

    @objid ("fcd1db21-d302-43be-a33d-8f4977ff02f9")
    public Produit ListeProduit;

    @objid ("045b0597-52aa-4cb0-825d-128e56905fd0")
    private void login() {
    }

    @objid ("717aa05e-36d6-461a-8b45-e24c771423a1")
    private void vendreObjet() {
    }

    @objid ("59126644-2246-40c4-b935-c3f218eafa2b")
    private void chercherPar() {
    }

    @objid ("21a5068a-e3cb-480b-a771-a30854eb3d03")
    private void ouvrirCompteVendeur() {
    }

    @objid ("76bba396-686a-4bc6-9851-7b5be7dea3a0")
    private void ouvrirCompteAcheteur() {
    }

    @objid ("d4cb01ce-55c6-4e23-8846-57c61a0295b3")
    private void encherir(int productID, int somme, Inscrit user) {
        // Créer un objet Enchère en cherchant dans la base de donnée l'enchère avec le même productID
        // Créer un objet Offres avec sommme et user 
        // Comparer la somme et le prix actuel 
            // Si plus grande
                // Ajouter l'objet Offres dans la liste des Offres de l'enchères 
                // Mettre à jour le prix actuel de l'Enchère 
                // Mettre à jour la BDD
                // Retourner succès 
            // Sinon 
                // Retourner échec
    }
    @objid ("d4cb01ce-55c6-4e23-8846-57c61a0295b3")
    private void evaluer(int valeur, string avis, Inscrit user, Inscrit evalue) {
        // Créer un objet Evaluation avec valeur, avis et user
        // Parcourir la liste d'évaluation de evalue
            // Si présence d'une evaluation du même user
                // Retourner echec 
            // Sinon 
                // Ajouter l'objet Evaluation dans la liste des Evaluation de evalue 
                // Mettre à jour la BDD 
                // Retourner succès
    }

    @objid ("d4d41353-0b05-409d-b352-5e5b961cc876")
    private void acheterDirect() {
    }

    @objid ("a5f151dc-4263-4fb4-ab30-54467c31298b")
    private void logout() {
    }

    @objid ("b90023ce-3f5a-48eb-b808-58a83328d4c7")
    public static void main() {
    }

    @objid ("9e6b5524-fda9-444e-b87c-a5d67afc2427")
    public String getUserToken() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.userToken;
    }

    @objid ("aff25283-bcdf-4a2b-a77e-a0cda2a49615")
    public void setUserToken(final String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.userToken = value;
    }

}
