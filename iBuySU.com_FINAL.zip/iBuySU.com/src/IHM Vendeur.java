import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("fafcfb27-0226-4d42-a411-b19b5f0d25ba")
public class IHM Vendeur extends IHM {
    @objid ("320cba7f-cb84-456a-8c60-b9ecd88b2fef")
    private void menuVendeur() {
    }

    @objid ("986d313d-af03-4676-9bd2-f598b557826f")
    private void vendre() {
    }

}
