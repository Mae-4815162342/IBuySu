import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("fdc12efc-80dd-4f5d-a2ef-8c02f16d493a")
public class RIB extends Données bancaires {
    @mdl.prop
    @objid ("ed2c932d-962c-474f-a024-70653ce2304b")
    private String IBAN;

    @mdl.propgetter
    private String getIBAN() {
        // Automatically generated method. Please do not modify this code.
        return this.IBAN;
    }

    @mdl.propsetter
    private void setIBAN(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.IBAN = value;
    }

    @mdl.prop
    @objid ("f6278e96-d7e9-4568-9f15-c0d8c7ed0b13")
    private String BIC;

    @mdl.propgetter
    private String getBIC() {
        // Automatically generated method. Please do not modify this code.
        return this.BIC;
    }

    @mdl.propsetter
    private void setBIC(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.BIC = value;
    }

    @objid ("34582209-66d2-4ded-be3f-f484a65616dc")
    public RIB() {
    }

}
