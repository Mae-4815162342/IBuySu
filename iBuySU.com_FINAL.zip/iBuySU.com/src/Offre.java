import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("e3257595-7075-46c0-84ce-52d254c27515")
public class Offre {
    @objid ("7119215d-8fa7-4d5d-b330-348c76c497d1")
    public int somme;

    @objid ("36fe6ded-36d6-4e3f-9576-3a84824b3cdf")
    public Offre() {
    }
    public static insert(Offre o) {
        // Se placer sur la table de Offres
        // Ajouter une nouvelle ligne avec les infos de o
        // Ajouter la clé étrangre de l'utilisateur
        // Ajouter la clé étrangre de l'enchère
        // Retourne eo
    }
}
