import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("751ae6a0-6d23-48bb-91ae-a3fccaa39fbd")
public abstract class Données bancaires {
    @objid ("24d0f386-947c-4dc4-bd4f-aac73ce6b2b5")
    private String banque;

    @objid ("361c8fe6-df6a-45c7-9ba9-edb454a48b48")
    private String titulaire;

    @objid ("aec160b5-45f5-43d2-be54-0dda7c55275a")
    public String getTitulaire() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.titulaire;
    }

    @objid ("abaf5238-683d-4b77-853d-84d05ff03b2d")
    public void setTitulaire(final String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.titulaire = value;
    }

    @objid ("76e4a8a4-e17c-4c9e-bd5c-0a73c8155270")
    public String getBanque() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.banque;
    }

    @objid ("936ffd61-9f89-44df-a1e5-df58ba30c784")
    public void setBanque(final String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.banque = value;
    }

}
