import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("f0e49a92-c874-42b2-b812-db6e8610b4c3")
public class IHM Acheteur extends IHM {
    @objid ("14000c65-621b-41bd-89b8-ca2d98a843c7")
    private void menuAcheteur() {
    }

    @objid ("0dfda6b3-cb1f-4949-b23d-7d5117eae437")
    private void acheter() {
    
    }
    @objid ("eb4f50e9-7fee-44d0-a768-9e550ac8a5aa")
    private void encherir() {
        
    }
}
