import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("d942a713-a35f-4b65-b481-de201fdf484c")
public class Adresse {
    @mdl.prop
    @objid ("2b7cdcaa-d46e-45b4-8477-4e2e00a78441")
    private String ville;

    @mdl.propgetter
    private String getVille() {
        // Automatically generated method. Please do not modify this code.
        return this.ville;
    }

    @mdl.propsetter
    private void setVille(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.ville = value;
    }

    @mdl.prop
    @objid ("da20aa83-ce62-40f7-8b16-abb5b5835916")
    private int code-postale;

    @mdl.propgetter
    private int getCode-postale() {
        // Automatically generated method. Please do not modify this code.
        return this.code-postale;
    }

    @mdl.propsetter
    private void setCode-postale(final int value) {
        // Automatically generated method. Please do not modify this code.
        this.code-postale = value;
    }

    @mdl.prop
    @objid ("220039ab-ad84-4244-8fe7-a87c7e345f4f")
    private String pays ;

    @mdl.propgetter
    private String getPays () {
        // Automatically generated method. Please do not modify this code.
        return this.pays ;
    }

    @mdl.propsetter
    private void setPays (final String value) {
        // Automatically generated method. Please do not modify this code.
        this.pays  = value;
    }

    @mdl.prop
    @objid ("a3b7d546-4b7a-4f41-afa7-8972e1cff600")
    private int numero-rue;

    @mdl.propgetter
    private int getNumero-rue() {
        // Automatically generated method. Please do not modify this code.
        return this.numero-rue;
    }

    @mdl.propsetter
    private void setNumero-rue(final int value) {
        // Automatically generated method. Please do not modify this code.
        this.numero-rue = value;
    }

    @mdl.prop
    @objid ("ab41c6d2-40bc-4613-8a5e-b7db1ad10fe1")
    private String nom-rue;

    @mdl.propgetter
    private String getNom-rue() {
        // Automatically generated method. Please do not modify this code.
        return this.nom-rue;
    }

    @mdl.propsetter
    private void setNom-rue(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.nom-rue = value;
    }

}
